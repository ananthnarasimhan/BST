package bst;

/**
 * This represents an empty node of the generic binary search tree implementation.
 * 
 * @param <T> the type of element in this node
 */
public class GenericTreeEmptyNode<T extends Comparable<T>> implements GenericListTreeNode<T> {

  @Override
  public GenericListTreeNode<T> add(T data) {
    // TODO Auto-generated method stub
    return new GenericTreeElementNode<>(data, this, this);
  }

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public int height() {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public boolean present(T data) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public T minimum() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public T maximum() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String preOrder() {
    // TODO Auto-generated method stub
    return "";
  }

  @Override
  public String inOrder() {
    // TODO Auto-generated method stub
    return "";
  }

  @Override
  public String postOrder() {
    // TODO Auto-generated method stub
    return "";
  }

}

package bst;

/**
 * This is a non-empty node in a generic binary search tree. It contains the
 * object data and the left and right subtree of the tree.
 * 
 * @param <T> the type of the element in the list
 */
public class GenericTreeElementNode<T extends Comparable<T>> implements GenericListTreeNode<T> {
  private T value;
  private GenericListTreeNode<T> leftSubtree;
  private GenericListTreeNode<T> rightSubtree;

  /**
   * This is a constructor used to create a node of the tree.
   * 
   * @param data         the element at this node.
   * @param leftSubtree  the left subtree of the node
   * @param rightSubtree the right subtree of the node
   */
  public GenericTreeElementNode(T data, GenericListTreeNode<T> leftSubtree,
      GenericListTreeNode<T> rightSubtree) {
    this.value = data;
    this.leftSubtree = leftSubtree;
    this.rightSubtree = rightSubtree;
  }

  @Override
  public GenericListTreeNode<T> add(T data) {
    // TODO Auto-generated method stub
    if (data == null) {
      throw new IllegalArgumentException("data can't be null");
    }
    if (this.value.compareTo(data) > 0) {
      this.leftSubtree = this.leftSubtree.add(data);
    } else if (this.value.compareTo(data) < 0) {
      this.rightSubtree = this.rightSubtree.add(data);
    }
    return this;
  }

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return 1 + this.leftSubtree.size() + this.rightSubtree.size();
  }

  @Override
  public int height() {
    // TODO Auto-generated method stub
    return 1 + Math.max(this.leftSubtree.height(), this.rightSubtree.height());
  }

  @Override
  public boolean present(T data) {
    // TODO Auto-generated method stub
    if (data == null) {
      throw new IllegalArgumentException("data can't be null");
    }
    if (this.value.compareTo(data) > 0) {
      return this.leftSubtree.present(data);
    } else if (this.value.compareTo(data) < 0) {
      return this.rightSubtree.present(data);
    } else {
      return true;
    }
  }

  @Override
  public T minimum() {
    // TODO Auto-generated method stub
    if (this.leftSubtree.height() == 0) {
      return this.value;
    }
    return this.leftSubtree.minimum();
  }

  @Override
  public T maximum() {
    // TODO Auto-generated method stub
    if (this.rightSubtree.height() == 0) {
      return this.value;
    }
    return this.rightSubtree.maximum();
  }

  @Override
  public String preOrder() {
    // TODO Auto-generated method stub
    return String
        .format(this.value + " " + this.leftSubtree.preOrder() + this.rightSubtree.preOrder());
  }

  @Override
  public String inOrder() {
    // TODO Auto-generated method stub
    return String
        .format(this.leftSubtree.inOrder() + this.value + " " + this.rightSubtree.inOrder());
  }

  @Override
  public String postOrder() {
    // TODO Auto-generated method stub
    return String
        .format(this.leftSubtree.postOrder() + this.rightSubtree.postOrder() + this.value + " ");
  }

  @Override
  public String toString() {
    return this.inOrder();
  }

}

package bst;

/**
 * This is the implementation of a generic binary search tree. Specifically it
 * implements the BinarySearchTree interface
 * 
 * @author ananth
 *
 * @param <T> the type of data in tree node
 */
public class BinarySearchTreeImpl<T extends Comparable<T>> implements BinarySearchTree<T> {
  private GenericListTreeNode<T> head;

  /** Default constructor. */
  public BinarySearchTreeImpl() {
    // TODO Auto-generated constructor stub
    head = new GenericTreeEmptyNode<>();
  }

  @Override
  public void add(T data) {
    // TODO Auto-generated method stub
    this.head = head.add(data);
  }

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return head.size();
  }

  @Override
  public int height() {
    // TODO Auto-generated method stub
    return head.height();
  }

  @Override
  public boolean present(T data) {
    // TODO Auto-generated method stub
    return head.present(data);
  }

  @Override
  public T minimum() {
    // TODO Auto-generated method stub
    return head.minimum();
  }

  @Override
  public T maximum() {
    // TODO Auto-generated method stub
    return head.maximum();
  }

  @Override
  public String preOrder() {
    // TODO Auto-generated method stub
    String preOrderString = head.preOrder();
    return String.format("[" + preOrderString.substring(0, preOrderString.length() - 1) + "]");
  }

  @Override
  public String inOrder() {
    // TODO Auto-generated method stub
    String inOrderString = head.inOrder();
    return String.format("[" + inOrderString.substring(0, inOrderString.length() - 1) + "]");
  }

  @Override
  public String postOrder() {
    // TODO Auto-generated method stub
    String postOrderString = head.postOrder();
    return String.format("[" + postOrderString.substring(0, postOrderString.length() - 1) + "]");
  }

  @Override
  public String toString() {
    return this.inOrder();
  }

}

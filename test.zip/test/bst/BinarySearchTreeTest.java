package bst;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

/**
 * Testing the Binary search tree for various edge cases.
 * 
 * @author ananth
 *
 */
public class BinarySearchTreeTest {

  private BinarySearchTree<Integer> equalHeightTree;
  private BinarySearchTree<Integer> leftSkewTree;
  private BinarySearchTree<Integer> rightSkewTree;
  private BinarySearchTree<Integer> unequalHeightTree;
  private BinarySearchTree<Integer> onlyHeadTree;

  /**
   * Setting up various binary trees for testing.
   */
  @Before
  public void setUp() {
    equalHeightTree = new BinarySearchTreeImpl<>();
    equalHeightTree.add(5);
    equalHeightTree.add(3);
    equalHeightTree.add(4);
    equalHeightTree.add(2);
    equalHeightTree.add(7);
    equalHeightTree.add(9);
    equalHeightTree.add(6);

    leftSkewTree = new BinarySearchTreeImpl<>();
    leftSkewTree.add(9);
    leftSkewTree.add(8);
    leftSkewTree.add(7);
    leftSkewTree.add(6);
    leftSkewTree.add(5);
    leftSkewTree.add(4);
    leftSkewTree.add(3);

    rightSkewTree = new BinarySearchTreeImpl<>();
    rightSkewTree.add(3);
    rightSkewTree.add(4);
    rightSkewTree.add(5);
    rightSkewTree.add(6);
    rightSkewTree.add(7);

    unequalHeightTree = new BinarySearchTreeImpl<>();
    unequalHeightTree.add(5);
    unequalHeightTree.add(3);
    unequalHeightTree.add(4);
    unequalHeightTree.add(2);
    unequalHeightTree.add(7);

    onlyHeadTree = new BinarySearchTreeImpl<>();
    onlyHeadTree.add(5);
  }

  /**
   * Testing for inorder in a equal tree.
   */
  @Test
  public void testinOrderForEqualHeight() {
    assertEquals("[2 3 4 5 6 7 9]", equalHeightTree.inOrder());
  }

  /**
   * Testing for preorder in a tree of equal height.
   */
  @Test
  public void testpreOrderEqualHeight() {
    assertEquals("[5 3 2 4 7 6 9]", equalHeightTree.preOrder());
  }

  /**
   * Testing for postorder in a tree of equal height.
   */
  @Test
  public void testpostOrderEqualHeight() {
    assertEquals("[2 4 3 6 9 7 5]", equalHeightTree.postOrder());
  }

  /**
   * Testing for construction of a tree of equal height.
   */
  @Test
  public void treeConstructedProperlyEqualHeight() {
    assertEquals("[5 3 2 4 7 6 9]", equalHeightTree.preOrder());
    assertEquals("[2 4 3 6 9 7 5]", equalHeightTree.postOrder());
  }

  /**
   * Testing for maximum node in a tree of equal height.
   */
  @Test
  public void maxNodeEqualHeight() {
    assertEquals("9", equalHeightTree.maximum().toString());
  }

  /**
   * Testing for minimum node in a tree of equal height.
   */
  @Test
  public void minNodeEqualHeight() {
    assertEquals("2", equalHeightTree.minimum().toString());
  }

  /**
   * Testing for size of a tree of equal height.
   */
  @Test
  public void treeSizeEqualHeight() {
    assertEquals(7, equalHeightTree.size());
  }

  /**
   * Testing for height of a tree of equal height.
   */
  @Test
  public void treeHeightEqualHeight() {
    assertEquals(3, equalHeightTree.height());
  }

  /**
   * Testing for inorder of a leftSkew tree.
   */

  @Test
  public void testinOrderForLeftSkewHeight() {
    assertEquals("[3 4 5 6 7 8 9]", leftSkewTree.inOrder());
  }

  /**
   * Testing for preorder of leftSkew tree.
   */
  @Test
  public void testpreOrderForLeftSkewHeight() {
    assertEquals("[9 8 7 6 5 4 3]", leftSkewTree.preOrder());
  }

  /**
   * Testing for postorder of a leftSkew tree.
   */
  @Test
  public void testpostOrderForLeftSkewHeight() {
    assertEquals("[3 4 5 6 7 8 9]", leftSkewTree.postOrder());
  }

  /**
   * Testing for construction of a leftSkew tree.
   */
  @Test
  public void treeConstructedProperlyForLeftSkewHeight() {
    assertEquals("[9 8 7 6 5 4 3]", leftSkewTree.preOrder());
    assertEquals("[3 4 5 6 7 8 9]", leftSkewTree.postOrder());
  }

  /**
   * Testing for maximum of a leftSkew tree.
   */
  @Test
  public void maxNodeForLeftSkewHeight() {
    assertEquals("9", leftSkewTree.maximum().toString());
  }

  /**
   * Testing for minimum of a leftSkew tree.
   */
  @Test
  public void minNodeForLeftSkewHeight() {
    assertEquals("3", leftSkewTree.minimum().toString());
  }

  /**
   * Testing for size of a leftSkew tree.
   */
  @Test
  public void treeSizeForLeftSkewHeight() {
    assertEquals(7, leftSkewTree.size());
  }

  /**
   * Testing for height of a leftSkew tree.
   */
  @Test
  public void treeHeightForLeftSkewHeight() {
    assertEquals(7, leftSkewTree.height());
  }

  /**
   * Testing for inorder of a right Skew tree.
   */
  @Test
  public void testinOrderForrightSkewTreeHeight() {
    assertEquals("[3 4 5 6 7]", rightSkewTree.inOrder());
  }

  /**
   * Testing for preorder of a right Skew tree.
   */
  @Test
  public void testpreOrderrightSkewTreeHeight() {
    assertEquals("[3 4 5 6 7]", rightSkewTree.preOrder());
  }

  /**
   * Testing for postorder of a right Skew tree.
   */
  @Test
  public void testpostOrderrightSkewTreeHeight() {
    assertEquals("[7 6 5 4 3]", rightSkewTree.postOrder());
  }

  /**
   * Testing for construction of a right Skew tree.
   */
  @Test
  public void treeConstructedProperlyrightSkewTreeHeight() {
    assertEquals("[3 4 5 6 7]", rightSkewTree.preOrder());
    assertEquals("[7 6 5 4 3]", rightSkewTree.postOrder());
  }

  /**
   * Testing for maximum of a right Skew tree.
   */
  @Test
  public void maxNoderightSkewTreeHeight() {
    assertEquals("7", rightSkewTree.maximum().toString());
  }

  /**
   * Testing for minimum of a right Skew tree.
   */
  @Test
  public void minNoderightSkewTreeHeight() {
    assertEquals("3", rightSkewTree.minimum().toString());
  }

  /**
   * Testing for size of a right Skew tree.
   */
  @Test
  public void treeSizerightSkewTreeHeight() {
    assertEquals(5, rightSkewTree.size());
  }

  /**
   * Testing for height of a right Skew tree.
   */
  @Test
  public void treeHeightrightSkewTreeHeight() {
    assertEquals(5, rightSkewTree.height());
  }

  /**
   * Testing for inorder of a tree of unequal height.
   */
  @Test
  public void testinOrderForUnequalHeight() {
    assertEquals("[2 3 4 5 7]", unequalHeightTree.inOrder());
  }

  /**
   * Testing for preorder of a tree of unequal height.
   */
  @Test
  public void testpreOrderUnequalHeight() {
    assertEquals("[5 3 2 4 7]", unequalHeightTree.preOrder());
  }

  /**
   * Testing for postorder of a tree of unequal height.
   */
  @Test
  public void testpostOrderUnequalHeight() {
    assertEquals("[2 4 3 7 5]", unequalHeightTree.postOrder());
  }

  /**
   * Testing for construction of a tree of unequal height.
   */
  @Test
  public void treeConstructedProperlyUnequalHeight() {
    assertEquals("[5 3 2 4 7]", unequalHeightTree.preOrder());
    assertEquals("[2 4 3 7 5]", unequalHeightTree.postOrder());
  }

  /**
   * Testing for maximum of a tree of unequal height.
   */
  @Test
  public void maxNodeUnequalHeight() {
    assertEquals("7", unequalHeightTree.maximum().toString());
  }

  /**
   * Testing for minimum of a tree of unequal height.
   */
  @Test
  public void minNodeUnequalHeight() {
    assertEquals("2", unequalHeightTree.minimum().toString());
  }

  /**
   * Testing for size of a tree of unequal height.
   */
  @Test
  public void treeSizeUnequalHeight() {
    assertEquals(5, unequalHeightTree.size());
  }

  /**
   * Testing for height of a tree of unequal height.
   */
  @Test
  public void treeHeightUnequalHeight() {
    assertEquals(3, unequalHeightTree.height());
  }

  /**
   * Testing for inorder of a tree with only head.
   */
  @Test
  public void testinOrderForonlyHeadHeight() {
    assertEquals("[5]", onlyHeadTree.inOrder());
  }

  /**
   * Testing for preorder of a tree with only head.
   */
  @Test
  public void testpreOrderonlyHeadlHeight() {
    assertEquals("[5]", onlyHeadTree.preOrder());
  }

  /**
   * Testing for postorder of a tree with only head.
   */
  @Test
  public void testpostOrderonlyHeadHeight() {
    assertEquals("[5]", onlyHeadTree.postOrder());
  }

  /**
   * Testing for construction of a tree with only head.
   */
  @Test
  public void treeConstructedProperlyonlyHeadHeight() {
    assertEquals("[5]", onlyHeadTree.preOrder());
    assertEquals("[5]", onlyHeadTree.postOrder());
  }

  /**
   * Testing for height of a tree with only head.
   */
  @Test
  public void maxNodeonlyHeadHeight() {
    assertEquals("5", onlyHeadTree.maximum().toString());
  }

  /**
   * Testing for minimum of a tree with only head.
   */
  @Test
  public void minNodeonlyHeadHeight() {
    assertEquals("5", onlyHeadTree.minimum().toString());
  }

  /**
   * Testing for maximum of a tree with only head.
   */
  @Test
  public void treeSizeonlyHeadHeight() {
    assertEquals(1, onlyHeadTree.size());
  }

  /**
   * Testing for height of a tree with only head.
   */
  @Test
  public void treeHeightonlyHeadHeight() {
    assertEquals(1, onlyHeadTree.height());
  }

  /**
   * Testing for node not present in a tree.
   */
  @Test
  public void testNotPresent() {
    assertEquals(false, equalHeightTree.present(35));
  }

  /**
   * Testing for node present at head in a tree.
   */
  @Test
  public void presentatHead() {
    assertEquals(true, equalHeightTree.present(5));
  }

  /**
   * Testing for node present at not a leaf or head in a tree.
   */
  @Test
  public void presentatNonLeaf() {
    assertEquals(true, equalHeightTree.present(3));
  }

  /**
   * Testing for node present at leaf in a tree.
   */
  @Test
  public void presentatLeaf() {
    assertEquals(true, equalHeightTree.present(2));
  }

  /**
   * Testing for adding null to a tree.
   */
  @Test(expected = IllegalArgumentException.class)
  public void nullAdd() {
    equalHeightTree.add(null);
  }

  /**
   * Testing for checking if null present in a tree.
   */
  @Test(expected = IllegalArgumentException.class)
  public void nullPresent() {
    equalHeightTree.present(null);
  }

  /**
   * Testing for maximum of an empty tree.
   */
  @Test
  public void nullTreeMaximum() {
    BinarySearchTree<Integer> emptyTree;
    emptyTree = new BinarySearchTreeImpl<>();
    assertNull(emptyTree.maximum());
  }

  /**
   * Testing for minimum of an empty tree.
   */
  @Test
  public void nullTreeMinimum() {
    BinarySearchTree<Integer> emptyTree;
    emptyTree = new BinarySearchTreeImpl<>();
    assertNull(emptyTree.minimum());
  }

  /**
   * Testing for height of an empty tree.
   */
  @Test
  public void nullTreeHeight() {
    BinarySearchTree<Integer> emptyTree;
    emptyTree = new BinarySearchTreeImpl<>();
    assertEquals(0, emptyTree.height());
  }

  /**
   * Testing for adding an existing element in a tree.
   */
  @Test
  public void addExitingElement() {
    equalHeightTree.add(5);
    assertEquals("[5 3 2 4 7 6 9]", equalHeightTree.preOrder());
    assertEquals("[2 4 3 6 9 7 5]", equalHeightTree.postOrder());
  }

  /**
   * Testing for toString output.
   */
  @Test
  public void chktoString() {
    assertEquals("[2 3 4 5 6 7 9]", equalHeightTree.toString());
  }

}
